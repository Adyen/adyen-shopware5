<?php

declare(strict_types=1);

namespace AdyenPayment\Models\RecurringPayment;

use AdyenPayment\Models\PaymentResultCode;
use AdyenPayment\Models\TokenIdentifier;
use Doctrine\ORM\Mapping as ORM;
use Shopware\Components\Model\ModelEntity;

/**
 * @ORM\Entity
 * @ORM\Table(name="s_plugin_adyen_payment_recurring_payment_token", indexes={
 *     @ORM\Index(name="idx_customer_id", columns={"customer_id"}),
 *     @ORM\Index(name="idx_psp_reference", columns={"psp_reference"}),
 *     @ORM\Index(name="idx_order_number", columns={"order_number"})
 * })
 */
class RecurringPaymentToken extends ModelEntity
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", nullable=false)
     * @ORM\Id
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="customer_id", type="string", length=255, nullable=false)
     */
    private $customerId;

    /**
     * @var string
     *
     * @ORM\Column(name="recurring_detail_reference", type="text", nullable=false)
     */
    private $recurringDetailReference;

    /**
     * @var string
     *
     * @ORM\Column(name="psp_reference", type="string", length=255, nullable=false)
     */
    private $pspReference;

    /**
     * @var string
     *
     * @ORM\Column(name="order_number", type="string", length=255, nullable=false)
     */
    private $orderNumber = '';

    /**
     * @var string
     *
     * @ORM\Column(name="result_code", type="text", nullable=false)
     */
    private $resultCode;

    /**
     * @var int
     *
     * @ORM\Column(name="amount_value", type="integer", nullable=false)
     */
    private $amountValue;

    /**
     * @var string
     *
     * @ORM\Column(name="amount_currency", type="text", nullable=false)
     */
    private $amountCurrency;

    /**
     * @var \DateTimeImmutable
     *
     * @ORM\Column(name="created_at", type="datetime_immutable")
     */
    private $createdAt;

    /**
     * @var \DateTimeImmutable
     *
     * @ORM\Column(name="updated_at", type="datetime_immutable")
     */
    private $updatedAt;

    private function __construct()
    {
        $this->setCreatedAt(new \DateTimeImmutable());
        $this->setUpdatedAt(new \DateTimeImmutable());
    }

    public static function create(
        TokenIdentifier $id,
        string $customerId,
        string $recurringDetailReference,
        string $pspReference,
        string $orderNumber,
        PaymentResultCode $resultCode,
        int $amountValue,
        string $amountCurrency
    ): self {
        $new = new self();
        $new->id = $id->identifier();
        $new->customerId = $customerId;
        $new->recurringDetailReference = $recurringDetailReference;
        $new->pspReference = $pspReference;
        $new->orderNumber = $orderNumber;
        $new->resultCode = $resultCode->resultCode();
        $new->amountValue = $amountValue;
        $new->amountCurrency = $amountCurrency;

        return $new;
    }

    /**
     * @internal
     *
     * @see RecurringPaymentToken::tokenIdentifier()
     */
    public function id(): string
    {
        return $this->id;
    }

    public function tokenIdentifier(): TokenIdentifier
    {
        return TokenIdentifier::generateFromString($this->id);
    }

    public function customerId(): string
    {
        return $this->customerId;
    }

    public function recurringDetailReference(): string
    {
        return $this->recurringDetailReference;
    }

    public function pspReference(): string
    {
        return $this->pspReference;
    }

    public function orderNumber(): string
    {
        return $this->orderNumber;
    }

    /**
     * @internal
     *
     * @see RecurringPaymentToken::resultCode()
     */
    public function getResultCode(): string
    {
        return $this->resultCode;
    }

    public function resultCode(): PaymentResultCode
    {
        return PaymentResultCode::load($this->resultCode);
    }

    public function amountValue(): int
    {
        return $this->amountValue;
    }

    public function amountCurrency(): string
    {
        return $this->amountCurrency;
    }

    public function createdAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeImmutable $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function updatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeImmutable $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function isSubscription(): bool
    {
        return '' === $this->orderNumber();
    }

    public function isOneOffPayment(): bool
    {
        return '' !== $this->orderNumber();
    }
}
