<?php

declare(strict_types=1);

namespace AdyenPayment\Models\Enum;

/**
 * Class Channel.
 */
class Channel
{
    public const WEB = 'Web';
}
