//{block name="backend/order/application"}
//      {$smarty.block.parent}
//      {include file="backend/adyen_payment_order/view/detail/transaction_details.js"}
//      {include file="backend/adyen_payment_order/view/detail/transaction_tabs.js"}
//      {include file="backend/adyen_payment_order/view/detail/tabs/notifications.js"}
//      {include file="backend/adyen_payment_order/view/detail/tabs/refunds.js"}
//      {include file="backend/adyen_payment_order/view/detail/tabs/notifications/list.js"}
//      {include file="backend/adyen_payment_order/view/detail/tabs/notifications/detail.js"}
//      {include file="backend/adyen_payment_order/view/detail/tabs/refunds/detail.js"}
//{/block}