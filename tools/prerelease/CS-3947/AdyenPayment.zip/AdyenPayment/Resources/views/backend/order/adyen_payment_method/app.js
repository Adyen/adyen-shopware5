//{block name="backend/order/application"}
    //{$smarty.block.parent}
    //{include file="backend/order/adyen_payment_method/view/list.js"}
//{/block}