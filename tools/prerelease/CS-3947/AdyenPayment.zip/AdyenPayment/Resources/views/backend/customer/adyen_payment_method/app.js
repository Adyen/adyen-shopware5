//{block name="backend/customer/application"}
    //{$smarty.block.parent}
    //{include file="backend/customer/adyen_payment_method/view/list.js"}
//{/block}